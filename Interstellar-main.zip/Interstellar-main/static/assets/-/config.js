self.__uv$config = {
    prefix: '/a/',
    bare: '/ov/',
    encodeUrl: Ultraviolet.codec.xor.encode,
    decodeUrl: Ultraviolet.codec.xor.decode,
    handler: '/assets/-/handler.js?v=5-5-2024',
    bundle: '/assets/-/bundle.js?v=5-5-2024',
    config: '/assets/-/config.js?v=5-5-2024',
    sw: '/assets/-/sw.js?v=5-5-2024',
};